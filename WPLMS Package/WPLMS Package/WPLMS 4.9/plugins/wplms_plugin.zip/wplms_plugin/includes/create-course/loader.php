<?php


if ( ! defined( 'ABSPATH' ) ) exit;

require_once(dirname(__FILE__).'/functions.php');

require_once(dirname(__FILE__).'/course_tabs.php');
require_once(dirname(__FILE__).'/api/class.api.php');
require_once(dirname(__FILE__).'/class.create_course.php');
require_once(dirname(__FILE__).'/class.filters.php');
require_once(dirname(__FILE__).'/upload.course.php');