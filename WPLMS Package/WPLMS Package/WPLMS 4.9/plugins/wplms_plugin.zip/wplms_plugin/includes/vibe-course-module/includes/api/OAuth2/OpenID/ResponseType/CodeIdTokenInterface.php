<?php

namespace OAuth2\OpenID\ResponseType;

use OAuth2\ResponseType\ResponseTypeInterface;

interface CodeIdTokenInterface extends ResponseTypeInterface
{
}
