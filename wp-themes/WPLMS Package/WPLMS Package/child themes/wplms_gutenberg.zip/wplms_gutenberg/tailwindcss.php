<div class="mt-2 mt-4 mt-6 mt-8 mt-10 rounded my-2 my-4 my-6 my-8 py-6 p-6 m-6 inline inline-block block items-start gap-1 hidden hover:flex absolute static fixed relative
justify-between py-4 w-8 w-16 w-24 w-32 w-40 w-56 w-64 w-80 text-left text-center text-right p-2 px-2 px-4">
<span class="opacity-0	
opacity-50	
opacity-60
opacity-70	
opacity-75
opacity-80
opacity-90	
opacity-100
rounded-xl items-start
rounded-tr-xl rounded-tl-xl">
</div>