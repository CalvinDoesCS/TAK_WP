<?php

if ( !defined( 'VIBE_URL' ) )
define('VIBE_URL',get_template_directory_uri());


define('WPLMS_APP_THEME_VERSION',rand(0,99999));

include_once('customisations.php');


