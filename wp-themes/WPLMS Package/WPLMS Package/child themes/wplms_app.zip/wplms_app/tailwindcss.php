<div class="mt-2 mt-4 mt-6 mt-8 mt-10 rounded my-2 my-4 my-6 my-8 py-6 p-6 m-6 inline inline-block block items-start
justify-between py-4 w-8 w-16 w-24 w-32 w-40 w-56 w-64 w-80 text-left text-center text-right">
</div>